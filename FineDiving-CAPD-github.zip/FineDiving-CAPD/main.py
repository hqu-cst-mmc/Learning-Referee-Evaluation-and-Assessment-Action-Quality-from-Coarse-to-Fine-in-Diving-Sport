import argparse
import os
import time
import shutil

import numpy as np
import torch
import torchvision
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
from torch.nn.utils import clip_grad_norm
import torch.nn as nn
from dataset import TSNDataSet
from MTL_dataset import MTLPair_Dataset
from FineDiving_Pair import FineDiving_Pair_Dataset
from models import TSN
from transforms import *
# from opts import parser
from utils import parser
from scipy import stats
from torchvideotransforms import video_transforms, volume_transforms
from utils import misc
import os, sys
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(BASE_DIR)
sys.path.append(os.path.join(BASE_DIR, "../"))
best_prec1 = 0
from models_tools import vit_encoder
from models_tools import vit_decoder
from models_tools import contrastive_fusion
from models_tools import MLP
from models_tools import MLP_timesformer
from models_tools import judge_model
from models_tools import Group_helper
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter
from models_tools.pspnet import PSPNet
from timesformer.models.vit import TimeSformer
from utils.save_model import save_checkpoint
from utils.resume_train import resume_train
def video_segment(args,video):
    # bs,1,96,3,299,299
    batch_size = video.size()[0]
    video_pack = torch.zeros(batch_size, 1, args.segments_num*args.segment_frame_num, 3, args.frame_HW,args.frame_HW).cuda()
    video = video.permute(0, 2, 1, 3, 4).unsqueeze(1)
    # 总共划分出3个阶段,3个子视频在3个阶段中分别取16帧
    # 分段采样
    if args.frame_select_strategy == "segment_sampling":
        start_idx = [[23, 39, 55], [0, 32, 64], [16, 48, 80]]
        for bs in range(0, batch_size):
            for idx in range(0, args.sub_video_num):
                video_seg = torch.cat([video[bs, :, i: i + args.segment_frame_num] for i in start_idx[idx]])
                video_pack[bs, idx] = video_seg
    # 奇偶采样
    elif args.frame_select_strategy == "odd_even_sampling":
        intersection_idx = [23, 39, 55]
        start_idx = [0 , 32, 64, 96]
        for bs in range(0, batch_size):
            if args.sub_video_num == 1:
                # 这是第三个视频取奇数帧
                # 1 :32:2->[1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31]
                # 33:64:2->[33, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59, 61, 63]
                # 65:96:2->[65, 67, 69, 71, 73, 75, 77, 79, 81, 83, 85, 87, 89, 91, 93, 95]
                video_seg = video[bs,:,1:96:2]
                video_pack[bs, 0] = video_seg
            else:
                if args.all_frames == 64:
                    # b,2,64,3,224,224
                    video_pack = torch.zeros(batch_size, 1, args.all_frames, 3, args.frame_HW, args.frame_HW).cuda()
                    indices_1 = [1, 3, 4, 6, 7, 9, 10, 12, 13, 15, 16, 18, 19, 21, 22, 24, 25, 27, 28, 30, 31, 33, 34,
                                 36, 37, 39,
                                 40, 42, 43, 45, 46, 48, 49, 51, 52, 54, 55, 57, 58, 60, 61, 63, 64, 66, 67, 69, 70, 72,
                                 73, 75, 76,
                                 78, 79, 81, 82, 84, 85, 87, 88, 90, 91, 93, 94, 95]
                    indices_2 = [0, 2, 3, 5, 6, 8, 9, 11, 12, 14, 15, 17, 18, 20, 21, 23, 24, 26, 27, 29, 30, 32, 33,
                                 35, 36, 38,
                                 39, 41, 42, 44, 45, 47, 48, 50, 51, 53, 54, 56, 57, 59, 60, 62, 63, 65, 66, 68, 69, 71,
                                 72, 74, 75,
                                 77, 78, 80, 81, 83, 84, 86, 87, 89, 90, 92, 93, 95]
                    for bs in range(0, batch_size):
                        for idx, indice in enumerate(indices_1):
                            video_pack[bs, 0, idx] = video[bs, 0, indice]
                        # for idx_2, indice_2 in enumerate(indices_2):
                        #     video_pack[bs, 1, idx_2] = video[bs, indice_2]
                else:
                    # # 总共取3个视频
                    # # 这是第一个视频取三个阶段的交集
                    # video_seg = video[bs,:,23:23+48]
                    # video_pack[bs, 0] = video_seg
                    # # 这是第二个视频取偶数帧
                    # # 0 :32:2->[0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30]
                    # # 32:64:2->[32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62]
                    # # 64:96:2->[64, 66, 68, 70, 72, 74, 76, 78, 80, 82, 84, 86, 88, 90, 92, 94]
                    video_seg = video[bs, :,0:96:2]
                    # video_pack[bs, 1] = video_seg
                    video_pack[bs, 0] = video_seg
                    # # 这是第三个视频取奇数帧
                    # # 1 :32:2->[1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31]
                    # # 33:64:2->[33, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59, 61, 63]
                    # # 65:96:2->[65, 67, 69, 71, 73, 75, 77, 79, 81, 83, 85, 87, 89, 91, 93, 95]
                    # video_seg = video[bs,:,1:96:2]
                    # video_pack[bs, 2] = video_seg
    return video_pack

# def create_labels(judge_scores,videos_num):
#     batch_size,judge_num = judge_scores.shape
#     partition_num = 21
#     prob_labels = torch.zeros(batch_size,judge_num,partition_num,dtype=torch.int64).cuda()
#     judge_scores_sort = judge_scores.sort().values
#     for bs in range(0,batch_size):
#         for i,judge_score in enumerate(judge_scores_sort[bs]):
#             index = judge_score // 0.5
#             prob_labels[bs,i,int(index)] = 1
#     return prob_labels.unsqueeze(1).expand(batch_size,videos_num,-1,-1)
def create_labels(judge_scores):
    judge_num = judge_scores.size(0)
    start_list = [0,6,7,7.5,8,8.5,10.5]
    score_list = []
    for i in range(0,len(start_list)-1):
        score_list.append([score for score in np.arange(start_list[i],start_list[i+1],0.5)])
    cls_labels = torch.zeros([judge_num,6],dtype=torch.int64).cuda()
    for j in range(0,judge_num):
        for i in range(0,len(score_list)):
            if judge_scores[j] in score_list[i]:
                cls_labels[j][i] = 1
                break
    return cls_labels,score_list
def create_indices(cls_prob):
    batch_size,judge_num,cls_num = cls_prob.size()
    predict_indices = torch.zeros([batch_size,judge_num],dtype=torch.int64).cuda()
    for bs in range(0,batch_size):
        for j in range(0,judge_num):
            predict_indices[bs][j] = cls_prob[bs][j].argmax(-1)
    return predict_indices

def compute_judge_score(reg,predict_indices,score_list):
    batch_size,judge_num = predict_indices.size()
    predict_judge_score = torch.zeros([batch_size,judge_num]).cuda()
    for bs in range(0,batch_size):
        for j in range(0,judge_num):
            # bs,j个裁判归属于那个类别
            index = predict_indices[bs][j]
            # 该类别的最小值
            start = score_list[index][0]
            # 该类别的最大值
            end = score_list[index][-1]
            score_range = end-start
            predict_judge_score[bs][j] = start + score_range * reg[bs][j][index]
    return predict_judge_score
def create_norm_judge_label(judge_scores,score_list):
    judge_num = judge_scores.size(0)
    norm_judge_label = torch.zeros([judge_num,6],requires_grad=True).cuda()
    for j in range(0,judge_num):
        judge_score = judge_scores[j]
        for i in range(0,len(score_list)):
            if judge_score in score_list[i]:
                if len(score_list[i]) == 1:
                    norm_judge_label[j][i] = 0
                else:
                    norm_judge_label[j][i] = (judge_score - score_list[i][0]) / (score_list[i][-1] - score_list[i][0])
            else:
                norm_judge_label[j][i] = -1
    return norm_judge_label
# def compute_score(predict_scores):
#     batch_size,video_num,judge_num = predict_scores.shape
#     predicts = torch.zeros(batch_size,video_num,1)
#     for bs in range(0,batch_size):
#         for v in range(0,video_num):
#             predict = predict_scores[bs][v]
#             predict = predict.sort().values
#             score = predict[2:5].sum()
#             predicts[bs][v] = score
#     return predicts
# def compute_score(predict_scores):
#     batch_size,judge_num = predict_scores.shape
#     predicts = torch.zeros(batch_size)
#     for bs in range(0,batch_size):
#         predict = predict_scores[bs]
#         predict = predict.sort().values
#         score = predict[2:5].sum()
#         predicts[bs] = score
#     return predicts

def select_judge(predict_scores,judge_scores):
    predict_scores = predict_scores.sort().values
    batch_size,video_num,judge_num = predict_scores.shape
    out_predict = torch.zeros(batch_size,video_num,4)
    out_judge = torch.zeros(batch_size,video_num,4)
    in_predict = torch.zeros(batch_size,video_num,3)
    in_judge = torch.zeros(batch_size,video_num,3)
    for bs in range(0,batch_size):
       for v in range(0,video_num):
            out_predict_scores = torch.cat((predict_scores[bs][v][0:2],predict_scores[bs][v][5:]))
            out_judge_scores = torch.cat((judge_scores[bs][v][0:2],judge_scores[bs][v][5:]))
            out_predict[bs][v] = out_predict_scores
            out_judge[bs][v] = out_judge_scores
            in_predict[bs][v] = predict_scores[bs][v][2:5]
            in_judge[bs][v] = judge_scores[bs][v][2:5]
    out_predict,out_judge,in_predict,in_judge

def seed_worker(worker_id):
    worker_seed = torch.initial_seed() % 2 ** 32
    np.random.seed(worker_seed)
    random.seed(worker_seed)

def main():
    global args, best_prec1

    args = parser.get_args()
    parser.setup(args)
    if args.benchmark == 'MTL':
        if not args.usingDD:
            args.score_range = 100

    # ------随机种子------
    random_seed = 3407
    os.environ['PYTHONHASHSEED'] = str(random_seed)
    np.random.seed(random_seed)             # Numpy
    random.seed(random_seed)                # Python
    torch.manual_seed(random_seed)          # pytorch
    if torch.cuda.is_available():
        torch.cuda.manual_seed(random_seed + args.local_rank)
        torch.cuda.manual_seed_all(random_seed + args.local_rank)
        torch.backends.cudnn.deterministic = True
    # -------------------

    if args.backbone == "TSN":
        model = TSN(
                    num_class=1024, num_videos=args.sub_video_num,
                    num_segments=args.segments_num,segment_frame_num=args.segment_frame_num,
                    modality='RGB',
                    base_model='BNInception',
                    consensus_type='avg', dropout=0.8, partial_bn=not False).apply(misc.fix_bn)
        crop_size = model.crop_size
        scale_size = model.scale_size
        input_mean = model.input_mean
        input_std = model.input_std
        policies = model.get_optim_policies()
        train_augmentation = model.get_augmentation()
        normalize = GroupNormalize(input_mean, input_std)
        resize_scale = (512,320)
        resize_size = 299
        for group in policies:
            print(('group: {} has {} params, lr_mult: {}, decay_mult: {}'.format(
                group['name'], len(group['params']), group['lr_mult'], group['decay_mult'])))

    elif args.backbone == "Resnet":
        model = PSPNet()
        resize_scale = (455,256)
        resize_size = 224
    elif args.backbone == "timesformer":
        model = TimeSformer(
            img_size=224,   # 图像尺寸
            num_classes=768,
            num_frames=48,  # 三个片段每个16帧
            attention_type=args.attention_type,
            pretrained_model=args.pretrained_model)
        resize_scale = (455, 256)
        resize_size = 224
    # Transformer Encoder
    encoder = vit_encoder.encoder_fuser(dim=768,num_heads=12,num_layers=12,
                                    segment_frame_num=args.segment_frame_num,
                                        segments_num=args.segments_num,allframes=args.all_frames)
    # Contrastive Fusion
    fuser = contrastive_fusion.decoder_fuser(dim=768,num_heads=4,num_layers=2,query_num=3)
    # Transformer Decoder
    # decoder = vit_decoder.decoder_fuser(dim=768 * 2,num_heads=12,num_layers=12,query_num=3)
    decoder = vit_decoder.decoder_fuser(dim=768 * 2,num_heads=8,num_layers=4,query_num=3)
    # Degree
    if args.benchmark == "MTL":
        out_channel = 11
    elif args.benchmark == "FineDiving":
        out_channel = 12
    rater = judge_model.Judge(in_channel=768 * 2, out_channel=out_channel)
    if args.backbone =="timesformer":
        mlp = MLP_timesformer.MLP_tf(in_channel=768)
    else:
        mlp = MLP.MLP(in_channel=1024)


    # model = torch.nn.DataParallel(model, device_ids=args.gpus).cuda()
    model = model.cuda()
    model = nn.DataParallel(model)
    encoder = encoder.cuda()
    encoder = nn.DataParallel(encoder)
    fuser = fuser.cuda()
    fuser = nn.DataParallel(fuser)
    decoder = decoder.cuda()
    decoder = nn.DataParallel(decoder)
    rater = rater.cuda()
    rater = nn.DataParallel(rater)
    mlp = mlp.cuda()
    mlp = nn.DataParallel(mlp)

    cudnn.benchmark = True

    # MTL-AQA
    # group = Group_helper.Group(args, Symmetrical=True, Max=10., Min=0)
    # MTL-AQA judge_score group
    if args.benchmark == 'MTL':
        group = [[-10, -3], [-2.5, -2], [-1.5, -1.5], [-1.0, -1.0], [-0.5, -0.5], [0.0, 0.0], [0.5, 0.5], [1.0, 1.0], [1.5, 1.5], [2, 2.5], [3, 10]]
        train_loader = torch.utils.data.DataLoader(
            MTLPair_Dataset(args,transform=video_transforms.Compose([
                    video_transforms.RandomHorizontalFlip(),
                    video_transforms.Resize(resize_scale),
                    video_transforms.RandomCrop(resize_size),
                    volume_transforms.ClipToTensor(),
                    video_transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ]),
                            subset='train'),
            batch_size=args.bs_train, shuffle=True, num_workers=8, pin_memory=True, worker_init_fn=seed_worker
        )
        val_loader = torch.utils.data.DataLoader(
            MTLPair_Dataset(args,transform=video_transforms.Compose([
                    video_transforms.Resize(resize_scale),
                    video_transforms.CenterCrop(resize_size),
                    volume_transforms.ClipToTensor(),
                    video_transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])]),
                            subset='test'),
            batch_size=args.bs_test, shuffle=False, num_workers=8, pin_memory=True
        )
    elif args.benchmark == 'FineDiving':
        group = [[-10, -2.6], [-2.5, -1.7], [-1.6, -1.1], [-1.0, -0.6], [-0.5, -0.5], [-0.4, 0.0],
                 [0.0, 0.4], [0.5, 0.5], [0.6, 1.0], [1.1, 1.6], [1.7, 2.5], [2.6, 10]]
        train_loader = torch.utils.data.DataLoader(
            FineDiving_Pair_Dataset(args, transform=video_transforms.Compose([
                video_transforms.RandomHorizontalFlip(),
                video_transforms.Resize(resize_scale),
                video_transforms.RandomCrop(resize_size),
                volume_transforms.ClipToTensor(),
                video_transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ]),
                            subset='train'),
            batch_size=args.bs_train, shuffle=True, num_workers=8, pin_memory=True, worker_init_fn=seed_worker
        )
        val_loader = torch.utils.data.DataLoader(
            FineDiving_Pair_Dataset(args, transform=video_transforms.Compose([
                video_transforms.Resize(resize_scale),
                video_transforms.CenterCrop(resize_size),
                volume_transforms.ClipToTensor(),
                video_transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])]),
                            subset='test'),
            batch_size=args.bs_test, shuffle=False, num_workers=8, pin_memory=True
        )

    mse = nn.MSELoss().cuda()
    nll = nn.NLLLoss().cuda()
    bce = nn.BCELoss().cuda()
    # criterion = nn.CrossEntropyLoss(reduction='sum').cuda()
    # criterion = nn.NLLLoss().cuda()

    optimizer = optim.Adam([
        {'params': model.parameters(), 'lr': 0.00001},
        {'params': encoder.parameters(), 'lr': 0.00001},
        {'params': fuser.parameters(), 'lr': 0.00001},
        {'params': decoder.parameters(), 'lr': 0.00001},
        {'params': rater.parameters(), 'lr': 0.00001},
        {'params': mlp.parameters(), 'lr': 0.00001}], lr=args.base_lr, weight_decay=args.weight_decay)

    # tensorboard
    tensorboard_original_path = './tensorboard_log'
    log_dir_path = os.path.join(tensorboard_original_path, 'fd_seg64_4')
    writer = SummaryWriter(log_dir=log_dir_path)

    # best
    start_epoch = 0
    epoch_best = 0
    epoch_best_L2 = 0
    epoch_best_RL2 = 0
    rho_best = 0
    rho_best_L2 = 0
    rho_best_RL2 = 0
    L2_min = 1000
    L2_min_rho = 0
    L2_min_RL2 = 0
    RL2_min = 1000
    RL2_min_rho = 0
    RL2_min_L2 = 0

    # 复现！
    if args.resume:
        start_epoch, epoch_best, epoch_best_RL2, epoch_best_L2, rho_best, L2_min, RL2_min = resume_train(
            model, encoder, fuser, decoder, rater, mlp, optimizer, args)
        true_scores = []
        pred_scores = []
        test_true_scores = []
        test_pred_scores = []
        test_raw_preds = []
        test_complement = []
        diffs = []


        batch_loss, loss_cls, loss_reg, Acc_list, mae = validate(val_loader, model, encoder, fuser, decoder, rater, mlp, mse, nll, group, test_true_scores,test_pred_scores,test_raw_preds, test_complement, diffs,optimizer, start_epoch)
        # 评估训练集
        # 存储diff
        diffs = np.array(diffs)
        save_diffs_path = os.path.join(args.experiment_path, 'diffs.npy')
        np.save(save_diffs_path, diffs)

        test_pred_scores = np.array(test_pred_scores)
        test_true_scores = np.array(test_true_scores)
        test_raw_preds = np.array(test_raw_preds)
        test_complement = np.array(test_complement)
        # 存储true和pred
        save_true_path = os.path.join(args.experiment_path, 'true.npy')
        save_pred_path = os.path.join(args.experiment_path, 'pred.npy')
        np.save(save_true_path, test_true_scores)
        np.save(save_pred_path, test_pred_scores)
        # 是否为最佳轮
        flag = False
        rho, p = stats.spearmanr(test_pred_scores, test_true_scores)
        L2 = np.power(test_pred_scores - test_true_scores, 2).sum() / test_true_scores.shape[0]
        RL2 = np.power((test_pred_scores - test_true_scores) / (test_true_scores.max() - test_true_scores.min()),
                       2).sum() / \
              test_true_scores.shape[0]
        print('[TEST] EPOCH: %d, correlation: %.6f, RL2: %.6f, L2: %.6f' % (start_epoch, rho, RL2, L2))
        print('[TEST] EPOCH: %d, loss_cls: %.2f, loss_reg: %.2f, k1: %.2f%%, k2: %.2f%%, k3: %.2f%%, mae: %.4f' % (start_epoch, loss_cls, loss_reg, Acc_list[0]*100, Acc_list[1]*100, Acc_list[2]*100, mae))
        exit(0)
    for epoch in range(start_epoch, args.max_epoch):
        # adjust_learning_rate(optimizer, epoch, args.lr_steps)
        # path = './predict_true_result/vit_encoder_decoder_mlp/pred_true_train.txt'
        # with open(path, mode="a+", encoding="utf-8") as f:
        #     f.write(time.ctime(time.time()) + "\n")
        #     f.write("***train_第%d轮***"%(epoch+1))
        #     f.write("\n")
        # f.close()

        # 初始化变量
        true_scores = []
        pred_scores = []
        test_true_scores = []
        test_pred_scores = []
        train_raw_preds = []
        train_complement = []

        diffs = []
        # !!
        test_raw_preds = []
        test_complement = []
        # batch_loss, loss_cls, loss_reg, Acc_list, mae = validate(val_loader, model, encoder, fuser, decoder, rater, mlp, mse, nll, group, test_true_scores,test_pred_scores,test_raw_preds, test_complement, diffs,optimizer, start_epoch)

        # # ----------------train----------------
        batch_loss = train(train_loader, model, encoder, fuser, decoder,
                           rater, mlp, mse, nll, bce, group, true_scores, pred_scores,
                           train_raw_preds, train_complement, diffs, optimizer, epoch)
        # 评估训练集
        pred_scores = np.array(pred_scores)
        true_scores = np.array(true_scores)
        train_raw_preds = np.array(train_raw_preds)
        train_complement = np.array(train_complement)
        pred_train_path = 'predict_true_result/fd_seg64_4/train.txt'
        with open(pred_train_path, mode="a+", encoding="utf-8") as f:
            f.write(time.ctime(time.time()) + "\n")
            f.write("***train_第%d轮***" % (epoch + 1))
            f.write("\n")
            for p in train_raw_preds:
                f.write("%.3f\t" % p)
            f.write("\n")
            for t in train_complement:
                f.write("%.3f\t" % t)
            f.write("\n")
        f.close()

        rho, p = stats.spearmanr(pred_scores, true_scores)
        L2 = np.power(pred_scores - true_scores, 2).sum() / true_scores.shape[0]
        RL2 = np.power((pred_scores - true_scores) / (true_scores.max() - true_scores.min()), 2).sum() / \
              true_scores.shape[0]
        print('[TRAIN] EPOCH: %d, correlation: %.4f, batch_loss: %.4f, L2: %.4f, RL2: %.4f, lr1: %.4f, lr2: %.4f' % (
        epoch, rho, batch_loss, L2, RL2, optimizer.param_groups[0]['lr'], optimizer.param_groups[1]['lr']))

        # 保存迭代数据
        metrics_root_path = 'Metrics_iterator_res/fd_seg64_4'
        train_path = metrics_root_path + '/train.txt'
        with open(train_path, mode="a+", encoding="utf-8") as f:
            f.write(time.ctime(time.time()) + "\n")
            f.write("***train_第%d轮***\n" % (epoch + 1))
            f.write(
                '[TRAIN] EPOCH: %d, correlation: %.4f, batch_loss: %.4f, L2: %.4f, RL2: %.4f, lr1: %.4f, lr2: %.4f' % (
                    epoch, rho, batch_loss, L2, RL2, optimizer.param_groups[0]['lr'], optimizer.param_groups[1]['lr']))
            f.write('\n')
        f.close()

        # 上传到前端
        writer.add_scalar(tag="train_Src",
                          scalar_value=rho,
                          global_step=epoch + 1)
        writer.add_scalar(tag="train_Loss",
                          scalar_value=batch_loss,
                          global_step=epoch + 1)

        # --------------test----------------
        save_checkpoint(model, encoder, fuser, decoder, rater, mlp, optimizer, 668, epoch_best, epoch_best_RL2,
                        epoch_best_L2, rho_best, L2_min, RL2_min, args)
        # if (epoch < 100 and epoch % 3 == 0) or epoch >= 100:
        if epoch >= 100 or (epoch < 100 and (epoch % 30) == 0):
        # if epoch >= 150:
            test_raw_preds = []
            test_complement = []
            batch_loss, loss_cls, loss_reg, Acc_list, mae = validate(val_loader, model, encoder, fuser, decoder, rater, mlp, mse, nll, group, test_true_scores, test_pred_scores,
                                  test_raw_preds,test_complement,diffs,
                                  optimizer, epoch)
            # 评估训练集
            test_pred_scores = np.array(test_pred_scores)
            test_true_scores = np.array(test_true_scores)
            test_raw_preds = np.array(test_raw_preds)
            test_complement = np.array(test_complement)
            pred_test_path = 'predict_true_result/fd_seg64_4/test.txt'
            with open(pred_test_path, mode="a+", encoding="utf-8") as f:
                f.write(time.ctime(time.time()) + "\n")
                f.write("***test_第%d轮***" % (epoch + 1))
                f.write("\n")
                for p in test_raw_preds:
                    f.write("%.3f\t" % p)
                f.write("\n")
                for t in test_complement:
                    f.write("%.3f\t" % t)
                f.write("\n")
            f.close()
            # 是否为最佳轮
            flag = False
            rho, p = stats.spearmanr(test_pred_scores, test_true_scores)
            L2 = np.power(test_pred_scores - test_true_scores, 2).sum() / test_true_scores.shape[0]
            RL2 = np.power((test_pred_scores - test_true_scores) / (test_true_scores.max() - test_true_scores.min()),
                           2).sum() / \
                  test_true_scores.shape[0]
            if L2_min > L2:
                L2_min = L2
                L2_min_rho = rho
                L2_min_RL2 = RL2
                epoch_best_L2 = epoch
            if RL2_min > RL2:
                RL2_min = RL2
                RL2_min_rho = rho
                RL2_min_L2 = L2
                epoch_best_RL2 = epoch
                # 保存模型
                save_checkpoint(model, encoder, fuser, decoder, rater, mlp, optimizer, 666, epoch_best, epoch_best_RL2,
                                epoch_best_L2, rho_best, L2_min, RL2_min, args)

            if rho > rho_best:
                flag = True
                rho_best = rho
                rho_best_L2 = L2
                rho_best_RL2 = RL2
                epoch_best = epoch
                # 保存模型
                save_checkpoint(model, encoder, fuser, decoder, rater, mlp, optimizer, 667, epoch_best, epoch_best_RL2,
                                epoch_best_L2, rho_best, L2_min, RL2_min, args)

                print('-----New best found!-----')
            print('[TEST] EPOCH: %d, correlation: %.6f, RL2: %.6f, L2: %.6f' % (epoch, rho, RL2, L2))
            print('[TEST] EPOCH: %d, loss_cls: %.2f, loss_reg: %.2f, k1: %.2f%%, k2: %.2f%%, k3: %.2f%%, mae: %.4f' % (epoch, loss_cls, loss_reg, Acc_list[0]*100, Acc_list[1]*100, Acc_list[2]*100, mae))
            print('[TEST] EPOCH: %d, best correlation: %.6f, RL2: %.6f, L2: %.6f' % (
            epoch_best, rho_best, rho_best_RL2, rho_best_L2))
            print('[TEST] EPOCH: %d, best RL2: %.6f, correlation: %.6f, L2: %.6f' % (
            epoch_best_RL2, RL2_min, RL2_min_rho, RL2_min_L2))
            print('[TEST] EPOCH: %d, best L2: %.6f, correlation: %.6f, RL2: %.6f' % (
            epoch_best_L2, L2_min, L2_min_rho, L2_min_RL2))
            # save_checkpoint(model, encoder, fuser, decoder, rater, mlp, optimizer, 666, epoch_best, epoch_best_RL2,
            #                 epoch_best_L2, rho_best, L2_min, RL2_min, args)

            # 保存迭代结果
            # 测试路径
            metrics_root_path = 'Metrics_iterator_res/fd_seg64_4'
            test_path = metrics_root_path + '/test.txt'
            with open(test_path, mode="a+", encoding="utf-8") as f:
                f.write(time.ctime(time.time()) + "\n")
                f.write("***test_第%d轮***\n" % (epoch + 1))
                if flag:
                    f.write('-----New best found!-----\n')
                f.write('[TEST] EPOCH: %d, correlation: %.6f, L2: %.6f, RL2: %.6f\n' % (epoch, rho, RL2, L2))
                f.write('[TEST] EPOCH: %d, loss_cls: %.2f, loss_reg: %.2f, k1: %.2f%%, k2: %.2f%%, k3: %.2f%%, mae: %.4f\n' % (
                epoch, loss_cls, loss_reg, Acc_list[0] * 100, Acc_list[1] * 100, Acc_list[2] * 100, mae))

                f.write('[TEST] EPOCH: %d, best correlation: %.6f, L2: %.6f, RL2: %.6f\n' % (
                    epoch_best, rho_best, rho_best_RL2, rho_best_L2))
                f.write('[TEST] EPOCH: %d, best RL2: %.6f, correlation: %.6f, L2: %.6f\n' % (
                    epoch_best_RL2, RL2_min, RL2_min_rho, RL2_min_L2))
                f.write('[TEST] EPOCH: %d, best L2: %.6f, correlation: %.6f, RL2: %.6f\n' % (
                    epoch_best_L2, L2_min, L2_min_rho, L2_min_RL2))
            f.close()

            # 上传到前端
            writer.add_scalar(tag="test_Src",
                              scalar_value=rho,
                              global_step=epoch + 1)
            writer.add_scalar(tag="test_MSE",
                              scalar_value=L2,
                              global_step=epoch + 1)
            writer.add_scalar(tag="test_RL2",
                              scalar_value=RL2,
                              global_step=epoch + 1)
            writer.add_scalar(tag="test_Loss",
                              scalar_value=batch_loss,
                              global_step=epoch + 1)
            writer.add_scalar(tag="cls_Loss",
                              scalar_value=loss_cls,
                              global_step=epoch + 1)
            writer.add_scalar(tag="reg_Loss",
                              scalar_value=loss_reg,
                              global_step=epoch + 1)
            writer.add_scalar(tag="k1",
                              scalar_value=Acc_list[0],
                              global_step=epoch + 1)
            writer.add_scalar(tag="k2",
                              scalar_value=Acc_list[1],
                              global_step=epoch + 1)
            writer.add_scalar(tag="k3",
                              scalar_value=Acc_list[2],
                              global_step=epoch + 1)
            writer.add_scalar(tag="mae",
                              scalar_value=mae,
                              global_step=epoch + 1)



def get_contrastive_score(judge_scores,judge_scores_exemplar):
    contrastiveScore_v1_v2 = torch.zeros([judge_scores.size(0),3])
    contrastiveScore_v2_v1 = torch.zeros([judge_scores.size(0),3])
    for i in range(judge_scores.size(0)):
        contrastiveScore_v1_v2[i] = judge_scores[i] - judge_scores_exemplar[i]
        contrastiveScore_v2_v1[i] = judge_scores_exemplar[i] - judge_scores[i]
    return contrastiveScore_v1_v2 , contrastiveScore_v2_v1

def get_contrastive_label(group, contrastiveScore_v1_v2, contrastiveScore_v2_v1):
    clsLabel_v1_v2 = torch.zeros(contrastiveScore_v1_v2.size(0),dtype=torch.int64).cuda()
    normLabel_v1_v2 = torch.zeros(contrastiveScore_v1_v2.size(0),dtype=torch.float64,requires_grad=True).cuda()
    clsLabel_v2_v1 = torch.zeros(contrastiveScore_v2_v1.size(0),dtype=torch.int64).cuda()
    normLabel_v2_v1 = torch.zeros(contrastiveScore_v2_v1.size(0),dtype=torch.float64,requires_grad=True).cuda()
    for score_idx in range(contrastiveScore_v1_v2.size(0)):
        for group_idx,part in enumerate(group):
            if contrastiveScore_v1_v2[score_idx] >= part[0] and contrastiveScore_v1_v2[score_idx] <= part[1]:
                clsLabel_v1_v2[score_idx] = group_idx
                if part[0] == part[1]:
                    normLabel_v1_v2[score_idx] = 0
                else:
                    normLabel_v1_v2[score_idx] = (contrastiveScore_v1_v2[score_idx] - part[0]) / (part[1] - part[0])
            if contrastiveScore_v2_v1[score_idx] >= part[0] and contrastiveScore_v2_v1[score_idx] <= part[1]:
                clsLabel_v2_v1[score_idx] = group_idx
                if part[0] == part[1]:
                    normLabel_v2_v1[score_idx] = 0
                else:
                    normLabel_v2_v1[score_idx] = (contrastiveScore_v2_v1[score_idx] - part[0]) / (part[1] - part[0])
    return clsLabel_v1_v2, clsLabel_v2_v1, normLabel_v1_v2, normLabel_v2_v1

def get_contrastive_bcelabel(group, contrastiveScore_v1_v2, contrastiveScore_v2_v1):
    clsLabel_v1_v2 = torch.zeros([contrastiveScore_v1_v2.size(0), len(group)],dtype=torch.float32).cuda()
    normLabel_v1_v2 = torch.zeros(contrastiveScore_v1_v2.size(0),dtype=torch.float64,requires_grad=True).cuda()
    clsLabel_v2_v1 = torch.zeros([contrastiveScore_v2_v1.size(0), len(group)],dtype=torch.float32).cuda()
    normLabel_v2_v1 = torch.zeros(contrastiveScore_v2_v1.size(0),dtype=torch.float64,requires_grad=True).cuda()
    # contrastiveScore_v1_v2[0] = 0
    for score_idx in range(contrastiveScore_v1_v2.size(0)):
        for group_idx,part in enumerate(group):
            if contrastiveScore_v1_v2[score_idx] >= part[0] and contrastiveScore_v1_v2[score_idx] <= part[1]:
                clsLabel_v1_v2[score_idx, group_idx] = 1
                if part[0] == part[1]:
                    normLabel_v1_v2[score_idx] = 0
                else:
                    normLabel_v1_v2[score_idx] = (contrastiveScore_v1_v2[score_idx] - part[0]) / (part[1] - part[0])
            if contrastiveScore_v2_v1[score_idx] >= part[0] and contrastiveScore_v2_v1[score_idx] <= part[1]:
                clsLabel_v2_v1[score_idx, group_idx] = 1
                if part[0] == part[1]:
                    normLabel_v2_v1[score_idx] = 0
                else:
                    normLabel_v2_v1[score_idx] = (contrastiveScore_v2_v1[score_idx] - part[0]) / (part[1] - part[0])

    return clsLabel_v1_v2, clsLabel_v2_v1, normLabel_v1_v2, normLabel_v2_v1

def get_pred_label(cls_prob_1, cls_prob_2):
    predLabel_v1_v2 = torch.zeros(cls_prob_1.size(0),dtype=torch.int32)
    predLabel_v2_v1 = torch.zeros(cls_prob_2.size(0),dtype=torch.int32)
    for idx in range(cls_prob_1.size(0)):
        predLabel_v1_v2[idx] = cls_prob_1[idx].argmax()
        predLabel_v2_v1[idx] = cls_prob_2[idx].argmax()
    return predLabel_v1_v2, predLabel_v2_v1

def compute_score(group, normLabel_v1_v2, predLable_v1_v2, judge_scores_exemplar, diff):
    predict_score = []
    raw_score = []
    for bs in range(normLabel_v1_v2.size(0)):
        preds = 0.0
        for judge in range(normLabel_v1_v2.size(1)):
            judge_score = judge_scores_exemplar[bs][judge] + group[predLable_v1_v2[bs][judge]][0] + normLabel_v1_v2[bs][judge] * (group[predLable_v1_v2[bs][judge]][1] - group[predLable_v1_v2[bs][judge]][0])
            if judge_score < group[0][0]:
                judge_score = group[0][0]
            elif judge_score > group[-1][1]:
                judge_score = group[-1][1]
            preds += judge_score
        predict_score.append(float(preds) * diff[bs])
        raw_score.append(float(preds))
    return predict_score, raw_score

def train(train_loader, model, encoder, fuser, decoder, rater, mlp, mse, nll, bce, group,
          true_scores, pred_scores, train_raw_preds, train_complement, diffs, optimizer, epoch):
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()

    # if args.no_partialbn:
    #     model.module.partialBN(False)
    # else:
    #     model.module.partialBN(True)
    # model.module.partialBN(True)

    # switch to train mode
    model.train()
    encoder.train()
    fuser.train()
    decoder.train()
    rater.train()
    mlp.train()
    # 初始化一些变量
    num_iter = 0
    batch_loss = 0.0
    end = time.time()
    for batch_idx, (data, exemplar) in enumerate(train_loader):
        start = time.time()
        # measure data loading time
        data_time.update(time.time() - end)
        loss = 0.0
        # break
        num_iter += 1
        opti_flag = False

        # 分数
        # 总分
        true_scores.extend(data['final_score'].numpy())
        # 执行分数
        true_score = data['completeness'].numpy()
        train_complement.extend(true_score)
        true_score = torch.tensor(true_score, requires_grad=True).cuda()

        # data preparing
        # video_1 is the test video ; video_2 is exemplar
        if args.benchmark == 'MTL':
            # 输入视频
            video_1 = data['video'].float().cuda()  # N, C, T, H, W
            batch_size = video_1.size(0)
            judge_scores = [sorted(items)[2:5] for items in list(data['judge_scores'].numpy())]
            judge_scores = torch.tensor(judge_scores)
            # 示例视频
            video_2 = exemplar['video'].float().cuda()
            judge_scores_exemplar = [sorted(items)[2:5] for items in list(exemplar['judge_scores'].numpy())]
            judge_scores_exemplar = torch.tensor(judge_scores_exemplar)
            if args.usingDD:
                label_1 = data['completeness'].float().reshape(-1, 1).cuda()
                label_2 = exemplar['completeness'].float().reshape(-1,1).cuda()
            else:
                label_1 = data['final_score'].float().reshape(-1, 1).cuda()
                label_2 = exemplar['final_score'].float().reshape(-1,1).cuda()
            # if not args.dive_number_choosing and args.usingDD:
            # assert (data['difficulty'].float() == target['difficulty'].float()).all()
            diff = data['difficulty'].float().numpy()
            # exemplar video
            # video_2 = target['video'].float().cuda() # N, C, T, H, W
        elif args.benchmark == 'FineDiving':
            # 输入视频
            video_1 = data['video'].float().cuda()  # N, C, T, H, W
            batch_size = video_1.size(0)
            judge_scores = [sorted(items) for items in list(data['judge_scores'].numpy())]
            judge_scores = torch.tensor(judge_scores)
            # judge_scores = torch.tensor(judge_scores).cuda()
            # 示例视频
            video_2 = exemplar['video'].float().cuda()
            judge_scores_exemplar = [sorted(items) for items in list(exemplar['judge_scores'].numpy())]
            judge_scores_exemplar = torch.tensor(judge_scores_exemplar)
            # judge_scores_exemplar = torch.tensor(judge_scores_exemplar).cuda()
            if args.usingDD:
                label_1 = data['completeness'].float().reshape(-1, 1).cuda()
                label_2 = exemplar['completeness'].float().reshape(-1, 1).cuda()
            else:
                label_1 = data['final_score'].float().reshape(-1, 1).cuda()
                label_2 = exemplar['final_score'].float().reshape(-1, 1).cuda()
            # if not args.dive_number_choosing and args.usingDD:
            # assert (data['difficulty'].float() == target['difficulty'].float()).all()
            diff = data['difficulty'].float().numpy()
        elif args.benchmark == 'Seven':
            video_1 = data['video'].float().cuda()  # N, C, T, H, W
            label_1 = data['final_score'].float().reshape(-1, 1).cuda()
            # video_2 = target['video'].float().cuda()
            # label_2 = target['final_score'].float().reshape(-1,1).cuda()
            diff = None
        else:
            raise NotImplementedError()
        # forward
        if num_iter == args.step_per_update:
            num_iter = 0
            opti_flag = True


        # 获得3个子视频
        # [bs,1,48,3,224,224] video_1, video_2, feature_1, feature_2, encoder_res_1, encoder_res_2, combine_feature_1, combine_feature_2, combine_feature, decoder_res
        batch_size = video_1.size(0)
        # bs,1,64,3,224,224
        video_1 = video_1.permute(0, 2, 1, 3, 4).unsqueeze(1)
        video_2 = video_2.permute(0, 2, 1, 3, 4).unsqueeze(1)
        # # backbone
        # bs,1,64,768
        feature_1 = model(video_1)
        feature_2 = model(video_2)
        # # Encoder
        # bs,1,65,768
        encoder_res_1 = encoder(feature_1)
        encoder_res_2 = encoder(feature_2)
        # combine_feature_1: feature_1 + feature_2 combine_feature_2: feature_2 + feature_1
        # bs, 1, 768
        fuse_12 = fuser(encoder_res_1[:,:,0,:], encoder_res_2[:,:,0,:])
        fuse_21 = fuser(encoder_res_2[:,:,0,:], encoder_res_1[:,:,0,:])
        # bs, 1, 768 * 2
        combine_feature_1 = torch.cat((fuse_21, fuse_12),dim=-1)
        combine_feature_2 = torch.cat((fuse_12, fuse_21),dim=-1)
        # bs*2, 1, 768 * 2
        combine_feature = torch.cat((combine_feature_1,combine_feature_2),dim=0)
        # # Decoder
        # bs*2,1,3,768 * 2
        decoder_res = decoder(combine_feature)
        # # rater
        # bs*2,1,3,11
        reg, cls_prob, cls_prob_lf = rater(decoder_res)

        # for name, param in rater.named_parameters():
        #     print(name, param.grad)

        # -----
        cls_prob = cls_prob.squeeze(1)
        reg = reg.squeeze(1)
        cls_prob_lf = cls_prob_lf.squeeze(1)
        # -----
        # bs*3
        reg_1 = reg[0:reg.size(0) // 2].view(-1)
        reg_2 = reg[reg.size(0) // 2:].view(-1)
        # bs,3,11
        cls_prob_1 = cls_prob[0:cls_prob.size(0) // 2]
        cls_prob_2 = cls_prob[cls_prob.size(0) // 2:]
        # bs*3,11
        cls_prob_lf_1 = cls_prob_lf[0:cls_prob_lf.size(0) // 2].view(-1,*cls_prob_1.shape[2:])
        cls_prob_lf_2 = cls_prob_lf[cls_prob_lf.size(0) // 2:].view(-1,*cls_prob_1.shape[2:])
        # 1-计算预测的相对裁判分数标签
        # cls_prob_1:v1-v2  cls_prob_2:v2-v1
        predLabel_v1_v2, predLabel_v2_v1 = get_pred_label(cls_prob_1.view(-1,*cls_prob_1.shape[2:]), cls_prob_2.view(-1,*cls_prob_2.shape[2:]))
        # 2-计算两个视频的相对裁判分数
        contrastiveScore_v1_v2, contrastiveScore_v2_v1 = get_contrastive_score(judge_scores, judge_scores_exemplar)
        # 3-制作相对裁判分数标签，相对裁判分数归一化标签
        clsLabel_v1_v2, clsLabel_v2_v1, normLabel_v1_v2, normLabel_v2_v1 = get_contrastive_bcelabel(group, contrastiveScore_v1_v2.view(-1), contrastiveScore_v2_v1.view(-1))
        # clsLabel_v1_v2, clsLabel_v2_v1, normLabel_v1_v2, normLabel_v2_v1 = get_contrastive_label(group, contrastiveScore_v1_v2.view(-1), contrastiveScore_v2_v1.view(-1))
        # 4-计算分类损失
        loss_cls = 0.0
        loss_cls += bce(cls_prob_1.view(-1, *cls_prob_1.shape[2:]), clsLabel_v1_v2)
        loss_cls += bce(cls_prob_2.view(-1, *cls_prob_2.shape[2:]), clsLabel_v2_v1)
        # loss_cls += nll(cls_prob_lf_1, clsLabel_v1_v2)
        # loss_cls += nll(cls_prob_lf_2, clsLabel_v2_v1)
        # 5-计算回归损失
        loss_reg = 0.0
        num_reg = 0
        mask_1 = []
        mask_2 = []
        if args.benchmark == "MTL":
            for idx in range(reg_1.size(0)):
                if int(clsLabel_v1_v2[idx]) in [0,1,9,10]:
                    mask_1.append(True)
                else :
                    mask_1.append(False)
                if int(clsLabel_v2_v1[idx]) in [0,1,9,10]:
                    mask_2.append(True)
                else:
                    mask_2.append(False)
        elif args.benchmark == "FineDiving":
            clsLabel_v1_v2 = clsLabel_v1_v2.argmax(-1)
            clsLabel_v2_v1 = clsLabel_v2_v1.argmax(-1)
            for idx in range(reg_1.size(0)):
                if int(clsLabel_v1_v2[idx]) not in [4, 7]:
                    mask_1.append(True)
                else :
                    mask_1.append(False)
                if int(clsLabel_v2_v1[idx]) not in [4, 7]:
                    mask_2.append(True)
                else:
                    mask_2.append(False)
        mask_1 = torch.tensor(mask_1).cuda()
        mask_2 = torch.tensor(mask_2).cuda()
        loss += loss_cls
        if mask_1.sum() != 0:
            loss_reg += mse(reg_1[mask_1].reshape(-1,1).float(),normLabel_v1_v2[mask_1].reshape(-1,1).float())
            loss_reg += mse(reg_2[mask_2].reshape(-1,1).float(),normLabel_v2_v1[mask_2].reshape(-1,1).float())
            loss += loss_reg
        # for idx in range(reg_1.size(0)):
        #     if int(clsLabel_v1_v2[idx]) in [0,1,9,10]:
        #         num_reg += 1
        #         loss_reg += mse(reg_1[idx].reshape(-1, 1).float(),normLabel_v1_v2[idx].reshape(-1, 1).float())
        #     if int(clsLabel_v2_v1[idx]) in [0,1,9,10]:
        #         num_reg += 1
        #         loss_reg += mse(reg_2[idx].reshape(-1, 1).float(),normLabel_v2_v1[idx].reshape(-1, 1).float())
        # 6-计算总损失，反向传播，梯度更新
        # if num_reg != 0:
        #     loss_reg = loss_reg / num_reg * 2
        #     loss += loss_cls + loss_reg
        # else:
        #     loss += loss_cls
        # loss += loss_cls
        # 7-计算总分
        predicts, raw = compute_score(group, reg_1.data.cpu().view(batch_size,3), predLabel_v1_v2.view(batch_size,3), judge_scores_exemplar.numpy(), diff)
        pred_scores.extend(predicts)
        train_raw_preds.extend(raw)
        batch_loss += loss.data.cpu().numpy()

        if opti_flag:
            optimizer.zero_grad()

        loss.backward()

        if opti_flag:
            optimizer.step()

        # -----------------
        end = time.time()
        batch_time = end - start
        if batch_idx % args.print_freq == 0:
            print('[Training][%d/%d][%d/%d] \t Batch_time %.2f \t Batch_loss: %.4f \t lr1 : %0.5f \t lr2 : %0.5f'
                  % (epoch, args.max_epoch, batch_idx, len(train_loader),
                     batch_time, loss.item(), optimizer.param_groups[0]['lr'], optimizer.param_groups[1]['lr']))
        # del video_1, video_2, feature_1, feature_2, encoder_res_1, encoder_res_2, combine_feature_1, combine_feature_2, combine_feature, decoder_res
        # # predicts = torch.round(predicts,decimals=3).data.cpu().numpy()
        # # predicts = predicts * 1000
        # # predicts = torch.round(predicts)
        # # predicts = predicts / 1000
        # predicts = compute_score(predict_judge_score)
        # # predicts = compute_score(predicts).squeeze(-1).mean(-1)
        # predicts = predicts.data.cpu().numpy()
        # train_raw_preds.extend(predicts)
        # diffs.extend(diff)
        # # pred_scores.extend([round(i[0].item() * i[1].item(),3) for i in zip(predicts, diff)])
        # # for i in zip(predicts,diff):
        # #     pred_scores.extend([i[0].item() * i[1].item()])
        # pred_scores.extend([i[0].item() * i[1].item() for i in zip(predicts, diff)])
    return batch_loss


def validate(test_loader, model, encoder, fuser, decoder, rater, mlp, mse, nll, group,
          true_scores, pred_scores, test_raw_preds, test_complement,diffs, optimizer, epoch):
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    top5 = AverageMeter()

    # if args.no_partialbn:
    #     model.module.partialBN(False)
    # else:
    #     model.module.partialBN(True)
    # model.module.partialBN(True)

    # switch to train mode
    model.eval()
    encoder.eval()
    fuser.eval()
    decoder.eval()
    rater.eval()
    mlp.eval()
    # 初始化一些变量
    num_iter = 0
    batch_loss = 0.0
    loss_cls = 0.0
    loss_reg = 0.0
    Acc_list = [0,0,0]
    mae = 0.0
    cls_num = 0
    reg_num = 0
    end = time.time()
    with torch.no_grad():
        for i, (data, exemplars) in enumerate(test_loader):
            start = time.time()
            # measure data loading time
            data_time.update(time.time() - end)

            true_scores.extend(data['final_score'].numpy())
            true_score = data['completeness'].numpy()
            test_complement.extend(true_score)
            true_score = torch.tensor(true_score, requires_grad=True).cuda()
            # data preparing
            # video_1 is the test video ; video_2 is exemplar
            if args.benchmark == 'MTL':
                # v1
                video_1 = data['video'].float().cuda()  # N, C, T, H, W
                judge_scores = [sorted(items)[2:5] for items in list(data['judge_scores'].numpy())]
                judge_scores = torch.tensor(judge_scores)
                # v2s
                video_2_list = [exemplar['video'].float().cuda() for exemplar in exemplars]
                judge_scores_exemplars_list = []
                for exemplar in exemplars:
                    judge_scores_exemplar = [sorted(items)[2:5] for items in list(exemplar['judge_scores'].numpy())]
                    judge_scores_exemplar = torch.tensor(judge_scores_exemplar)
                    judge_scores_exemplars_list.append(judge_scores_exemplar)
                if args.usingDD:
                    label_1 = data['completeness'].float().reshape(-1, 1).cuda()
                    # label_2 = target['completeness'].float().reshape(-1,1).cuda()
                else:
                    label_1 = data['final_score'].float().reshape(-1, 1).cuda()
                    # label_2 = target['final_score'].float().reshape(-1,1).cuda()
                # if not args.dive_number_choosing and args.usingDD:
                # assert (data['difficulty'].float() == target['difficulty'].float()).all()
                diff = data['difficulty'].float().numpy()
                # exemplar video
                # video_2 = target['video'].float().cuda() # N, C, T, H, W
            elif args.benchmark == 'FineDiving':
                # 输入视频
                video_1 = data['video'].float().cuda()  # N, C, T, H, W
                batch_size = video_1.size(0)
                judge_scores = [sorted(items) for items in list(data['judge_scores'].numpy())]
                judge_scores = torch.tensor(judge_scores)
                # judge_scores = torch.tensor(judge_scores).cuda()
                # 示例视频
                video_2_list = [exemplar['video'].float().cuda() for exemplar in exemplars]
                judge_scores_exemplars_list = []
                for exemplar in exemplars:
                    judge_scores_exemplar = [sorted(items) for items in list(exemplar['judge_scores'].numpy())]
                    judge_scores_exemplar = torch.tensor(judge_scores_exemplar)
                    judge_scores_exemplars_list.append(judge_scores_exemplar)
                # if args.usingDD:
                #     label_1 = data['completeness'].float().reshape(-1, 1).cuda()
                #     label_2 = exemplar['completeness'].float().reshape(-1, 1).cuda()
                # else:
                #     label_1 = data['final_score'].float().reshape(-1, 1).cuda()
                #     label_2 = exemplar['final_score'].float().reshape(-1, 1).cuda()
                # if not args.dive_number_choosing and args.usingDD:
                # assert (data['difficulty'].float() == target['difficulty'].float()).all()
                diff = data['difficulty'].float().numpy()
                diffs.extend(diff)
            elif args.benchmark == 'Seven':
                video_1 = data['video'].float().cuda()  # N, C, T, H, W
                label_1 = data['final_score'].float().reshape(-1, 1).cuda()
                # video_2 = target['video'].float().cuda()
                # label_2 = target['final_score'].float().reshape(-1,1).cuda()
                diff = None
            else:
                raise NotImplementedError()
            # ----
            video_1 = video_1.permute(0, 2, 1, 3, 4).unsqueeze(1)
            # video_1 = video_segment(args, video_1)
            feature_1 = model(video_1)
            encoder_res_1 = encoder(feature_1)
            # ----
            batch_size = video_1.size(0)
            predicts_sum = np.zeros(batch_size)
            raw_sum = np.zeros(batch_size)
            loss = 0.0
            for video_2, judge_scores_exemplar in zip(video_2_list, judge_scores_exemplars_list):

                # 获得3个子视频
                # bs,1,64,3,224,224
                video_2 = video_2.permute(0, 2, 1, 3, 4).unsqueeze(1)
                # # backbone
                # bs,3,48,768
                feature_2 = model(video_2)
                # # Encoder
                # bs,1,65,768
                encoder_res_2 = encoder(feature_2)
                # combine_feature_1: feature_1 + feature_2 combine_feature_2: feature_2 + feature_1
                # bs,1,768 * 2
                fuse_12 = fuser(encoder_res_1[:, :, 0, :], encoder_res_2[:, :, 0, :])
                fuse_21 = fuser(encoder_res_2[:, :, 0, :], encoder_res_1[:, :, 0, :])
                # bs*2,1,768 * 2
                combine_feature_1 = torch.cat((fuse_21, fuse_12), dim=-1)
                combine_feature_2 = torch.cat((fuse_12, fuse_21), dim=-1)
                combine_feature = torch.cat((combine_feature_1, combine_feature_2), dim=0)
                # # Decoder
                # bs*2,1,3,768 * 2
                decoder_res = decoder(combine_feature)
                # # rater
                # bs*2,1,3,11
                reg, cls_prob, cls_prob_lf = rater(decoder_res)

                # ---------
                cls_prob = cls_prob.squeeze(1)
                reg = reg.squeeze(1)
                cls_prob_lf = cls_prob_lf.squeeze(1)
                # -----
                reg_1 = reg[0:reg.size(0) // 2].view(-1)
                reg_2 = reg[reg.size(0) // 2:].view(-1)
                cls_prob_1 = cls_prob[0:cls_prob.size(0) // 2]
                cls_prob_2 = cls_prob[cls_prob.size(0) // 2:]
                cls_prob_lf_1 = cls_prob_lf[0:cls_prob_lf.size(0) // 2].view(-1, *cls_prob_1.shape[2:])
                cls_prob_lf_2 = cls_prob_lf[cls_prob_lf.size(0) // 2:].view(-1, *cls_prob_1.shape[2:])
                # 1-计算预测的相对裁判分数标签
                # cls_prob_1:v1-v2  cls_prob_2:v2-v1
                predLabel_v1_v2, predLabel_v2_v1 = get_pred_label(
                    cls_prob_1.view(-1, *cls_prob_1.shape[2:]),cls_prob_2.view(-1, *cls_prob_2.shape[2:]))
                # 2-计算两个视频的相对裁判分数
                contrastiveScore_v1_v2, contrastiveScore_v2_v1 = get_contrastive_score(judge_scores,judge_scores_exemplar)
                # 3-制作相对裁判分数标签，相对裁判分数归一化标签
                clsLabel_v1_v2, clsLabel_v2_v1, normLabel_v1_v2, normLabel_v2_v1 = get_contrastive_label(group,
                                                contrastiveScore_v1_v2.view(-1),contrastiveScore_v2_v1.view(-1))
                # 4-计算损失
                loss_cls += nll(cls_prob_lf_1, clsLabel_v1_v2)
                loss_cls += nll(cls_prob_lf_2, clsLabel_v2_v1)
                for idx in range(reg_1.size(0)):
                    if args.benchmark == "MTL":
                        if int(clsLabel_v1_v2[idx]) in [0, 1, 9, 10]:
                            reg_num += 1
                            mae += torch.abs((reg_1[idx].float() - normLabel_v1_v2[idx].float()))
                            loss_reg += mse(reg_1[idx].float(), normLabel_v1_v2[idx].float())
                        if int(clsLabel_v2_v1[idx]) in [0, 1, 9, 10]:
                            reg_num += 1
                            mae += torch.abs((reg_2[idx].float() - normLabel_v2_v1[idx].float()))
                            loss_reg += mse(reg_2[idx].float(), normLabel_v2_v1[idx].float())
                    elif args.benchmark == "FineDiving":
                        if int(clsLabel_v1_v2[idx]) not in [4, 7]:
                            reg_num += 1
                            mae += torch.abs((reg_1[idx].float() - normLabel_v1_v2[idx].float()))
                            loss_reg += mse(reg_1[idx].float(), normLabel_v1_v2[idx].float())
                        if int(clsLabel_v2_v1[idx]) not in [4, 7]:
                            reg_num += 1
                            mae += torch.abs((reg_2[idx].float() - normLabel_v2_v1[idx].float()))
                            loss_reg += mse(reg_2[idx].float(), normLabel_v2_v1[idx].float())

                # 5-计算总分
                predicts, raw = compute_score(group, reg_1.view(batch_size, 3),
                                         predLabel_v1_v2.view(batch_size, 3), judge_scores_exemplar.numpy(), diff)
                predicts = np.array(predicts)
                raw = np.array(raw)
                predicts_sum = predicts + predicts_sum
                raw_sum = raw + raw_sum
                # 6-计算分类准确率Acc
                dist = torch.abs((predLabel_v1_v2 - clsLabel_v1_v2.cpu()))
                cls_num += dist.size(0)
                for item in dist:
                    if int(item) == 0:
                        Acc_list[0] += 1
                    if int(item) <= 1:
                        Acc_list[1] += 1
                    if int(item) <= 2:
                        Acc_list[2] += 1

            # -------
            loss = loss_reg + loss_cls
            end = time.time()
            batch_time = end - start
            if i % args.print_freq == 0:
                print('[Testing][%d/%d][%d/%d] \t Batch_time %.2f\t'% (epoch, args.max_epoch, i, len(test_loader),batch_time))
            voter_num = len(video_2_list)
            pred_scores.extend([(pred / voter_num) for pred in predicts_sum])
            test_raw_preds.extend([(raw / voter_num) for raw in raw_sum])
            batch_loss += loss.data.cpu().numpy()
        for idx in range(len(Acc_list)):
            Acc_list[idx] = Acc_list[idx] / cls_num
    return batch_loss, loss_cls, loss_reg, Acc_list, mae / reg_num


# def save_checkpoint(state, is_best, filename='checkpoint.pth.tar'):
#     filename = '_'.join((args.snapshot_pref, args.modality.lower(), filename))
#     torch.save(state, filename)
#     if is_best:
#         best_name = '_'.join((args.snapshot_pref, args.modality.lower(), 'model_best.pth.tar'))
#         shutil.copyfile(filename, best_name)


class AverageMeter(object):
    """Computes and stores the average and current value"""
    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def adjust_learning_rate(optimizer, epoch, lr_steps):
    """Sets the learning rate to the initial LR decayed by 10 every 30 epochs"""
    decay = 0.1 ** (sum(epoch >= np.array(lr_steps)))
    lr = args.lr * decay
    decay = args.weight_decay
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr * param_group['lr_mult']
        param_group['weight_decay'] = decay * param_group['decay_mult']


def accuracy(output, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    maxk = max(topk)
    batch_size = target.size(0)

    _, pred = output.topk(maxk, 1, True, True)
    pred = pred.t()
    correct = pred.eq(target.view(1, -1).expand_as(pred))

    res = []
    for k in topk:
        correct_k = correct[:k].view(-1).float().sum(0)
        res.append(correct_k.mul_(100.0 / batch_size))
    return res


if __name__ == '__main__':
    main()
