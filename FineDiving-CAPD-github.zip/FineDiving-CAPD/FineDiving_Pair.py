import torch
import numpy as np
import os
import pickle
import random
import glob
from os.path import join
from PIL import Image

class FineDiving_Pair_Dataset(torch.utils.data.Dataset):
    def __init__(self, args, subset, transform):
        random.seed(args.seed)
        self.subset = subset
        self.transforms = transform
        self.random_choosing = args.random_choosing
        self.action_number_choosing = args.action_number_choosing
        self.length = args.frame_length
        self.voter_number = args.voter_number

        # file path
        self.data_root = args.data_root
        self.coarse_anno = self.read_pickle(args.coarse_path)
        self.data_anno = self.read_pickle(args.label_path)
        self.train_anno = self.read_pickle(args.train_anno_path)
        with open(args.train_split, 'rb') as f:
            self.train_dataset_list = pickle.load(f)
        with open(args.test_split, 'rb') as f:
            self.test_dataset_list = pickle.load(f)

        self.action_number_dict = {}
        self.difficulties_dict = {}
        if self.subset == 'train':
            self.dataset = self.train_dataset_list
        else:
            self.dataset = self.test_dataset_list
            self.action_number_dict_test = {}
            self.difficulties_dict_test = {}

        self.choose_list = self.train_dataset_list.copy()
        if self.action_number_choosing:
            self.preprocess()
            self.check_exemplar_dict()

    def preprocess(self):
        # !!
        # self.subset = 'test'
        self.action_number_dict_test = {}
        # !!
        for item in self.train_dataset_list:
            dive_number = self.train_anno.get(item)['action_type']
            difficulty = self.train_anno.get(item)['difficulty']
            if self.action_number_dict.get(dive_number) is None:
                self.action_number_dict[dive_number] = []
            self.action_number_dict[dive_number].append(item)
            if self.difficulties_dict.get(difficulty) is None:
                self.difficulties_dict[difficulty] = []
            self.difficulties_dict[difficulty].append(item)
        if self.subset == 'test':
            for item in self.test_dataset_list:
                dive_number = self.data_anno.get(item)['action_type']
                if self.action_number_dict_test.get(dive_number) is None:
                    self.action_number_dict_test[dive_number] = []
                self.action_number_dict_test[dive_number].append(item)

    def check_exemplar_dict(self):
        if self.subset == 'train':
            for key in sorted(list(self.action_number_dict.keys())):
                file_list = self.action_number_dict[key]
                for item in file_list:
                    assert self.train_anno[item]['action_type'] == key
            print("action_type check done!")
            for key in sorted(list(self.difficulties_dict.keys())):
                file_list = self.difficulties_dict[key]
                for item in file_list:
                    assert self.train_anno[item]['difficulty'] == key
            print("difficulty check done!")
        if self.subset == 'test':
            for key in sorted(list(self.action_number_dict_test.keys())):
                file_list = self.action_number_dict_test[key]
                for item in file_list:
                    assert self.data_anno[item]['action_type'] == key

    def load_video(self, video_file_name, subset='train'):
        if subset == 'train':
            image_list = sorted((glob.glob(os.path.join(self.data_root, 'train', video_file_name, '*.jpg'))))
            # indices_1 = [0, 2, 3, 5, 6, 8, 9, 11, 12, 14, 15, 17, 18, 20, 21, 23, 24, 26, 27, 29, 30, 32, 33, 35, 36, 38,
            #              39, 41, 42, 44, 45, 47, 48, 50, 51, 53, 54, 56, 57, 59, 60, 62, 63, 65, 66, 68, 69, 71, 72, 74, 75,
            #              77, 78, 80, 81, 83, 84, 86, 87, 89, 90, 92, 93, 95]
            # new_image_list = []
            # for i in indices_1:
            #     new_image_list.append(image_list[i])
            video = [Image.open(image_list[i]) for i in range(len(image_list))]
            if len(video) != 64:
                print("Error Train len!")
        elif subset == 'test':
            image_list = sorted((glob.glob(os.path.join(self.data_root, 'test', video_file_name[0], str(video_file_name[1]), '*.jpg'))))
            indices_1 = [0, 2, 3, 5, 6, 8, 9, 11, 12, 14, 15, 17, 18, 20, 21, 23, 24, 26, 27, 29, 30, 32, 33, 35, 36, 38,
                         39, 41, 42, 44, 45, 47, 48, 50, 51, 53, 54, 56, 57, 59, 60, 62, 63, 65, 66, 68, 69, 71, 72, 74,
                         75, 77, 78, 80, 81, 83, 84, 86, 87, 89, 90, 92, 93, 95]
            new_image_list = []
            for i in indices_1:
                new_image_list.append(image_list[i])
            video = [Image.open(new_image_list[i]) for i in range(len(new_image_list))]
            if len(video) != 64:
                print("Error Test len!")
        return self.transforms(video)


    def read_pickle(self, pickle_path):
        with open(pickle_path,'rb') as f:
            pickle_data = pickle.load(f)
        return pickle_data

    def __getitem__(self, index):
        # # 该训练集index 动作编号只有一个样本
        # index = 291
        # 测试集index
        # index = 17
        sample_1 = self.dataset[index]
        # 测试！！！！
        # sample_1 = ('07', 3)
        # sample_1 = ('10', 38)
        # #######################
        # 1- 选择目标视频
        # #######################
        data = {}
        data['video'] = self.load_video(sample_1, self.subset)
        if self.subset == 'train':
            data['number'] = self.train_anno.get(sample_1)['action_type']
            data['final_score'] = self.train_anno.get(sample_1)['dive_score']
            data['difficulty'] = self.train_anno.get(sample_1)['difficulty']
            data['completeness'] = round((data['final_score'] / data['difficulty']), 1)
            data['judge_scores'] = np.array(self.train_anno.get(sample_1)['judge_scores']).astype(np.float32)
            if round(sum(data['judge_scores']), 1) != data['completeness']:
                print("train judge scores Error!")
        elif self.subset == 'test':
            data['number'] = self.data_anno.get(sample_1)['action_type']
            data['final_score'] = self.data_anno.get(sample_1)['dive_score']
            data['difficulty'] = self.data_anno.get(sample_1)['difficulty']
            data['completeness'] = round((data['final_score'] / data['difficulty']), 1)
            judge = self.coarse_anno.get(sample_1)['judge_scores']
            if len(judge) == 3:
                data['judge_scores'] = np.array(judge).astype(np.float32)
            elif len(judge) == 5:
                all_judge = round(sum(judge), 1)
                # !!!!重点错误！！！5个裁判是裁判总分➗5然后平均分三份
                data['judge_scores'] = np.array([all_judge / 5, all_judge / 5, all_judge / 5]).astype(np.float32)
            elif len(judge) == 7:
                data['judge_scores'] = np.array(sorted(judge)[2:5]).astype(np.float32)
            if round(sum(data['judge_scores']), 1) != data['completeness']:
                print("test judge scores Error!")
        # choose a exemplar
        # #######################
        # 2.1- 训练集选择对比视频
        # #######################
        if self.subset == 'train':
            # train phrase
            if self.action_number_choosing == True:
                file_list = self.action_number_dict[self.train_anno[sample_1]['action_type']].copy()
            elif self.DD_choosing == True:
                file_list = self.difficulties_dict[self.data_anno[sample_1]['difficulty']].copy()
            else:
                # randomly
                file_list = self.train_dataset_list.copy()
            # exclude self
            if len(file_list) > 1:
                file_list.pop(file_list.index(sample_1))
            # choosing one out
            idx = random.randint(0, len(file_list) - 1)
            sample_2 = file_list[idx]
            target = {}
            target['video'] = self.load_video(sample_2, subset='train')
            target['number'] = self.train_anno.get(sample_2)['action_type']
            target['final_score'] = self.train_anno.get(sample_2)['dive_score']
            target['difficulty'] = self.train_anno.get(sample_2)['difficulty']
            target['completeness'] = round((target['final_score'] / target['difficulty']), 1)
            target['judge_scores'] = np.array(self.train_anno.get(sample_2)['judge_scores']).astype(np.float32)
            if round(sum(target['judge_scores']), 1) != target['completeness']:
                print("select train judge scores Error!")
            return data, target
        # #######################
        # 2.2- 测试集选择对比视频
        # #######################
        else:
            # test phrase
            if self.action_number_choosing:
                train_file_list = self.action_number_dict[self.data_anno[sample_1]['action_type']]
                action_len = len(train_file_list)
                random.shuffle(train_file_list)
                choosen_sample_list = train_file_list[:self.voter_number]
                # 如果动作编号列表中少于选举数，则从难度系数列表中借
                if len(train_file_list) < self.voter_number:
                    # borrow_list = self.difficulties_dict[self.data_anno[sample_1]['difficulty']]
                    borrow_list = self.difficulties_dict[self.data_anno[sample_1]['difficulty']].copy()
                    for choosen in choosen_sample_list:
                        try:
                            if borrow_list.count(choosen) !=0 :
                                borrow_list.pop(borrow_list.index(choosen))
                        except:
                            print(1)
                    random.shuffle(borrow_list)
                    # 这里可能会有和choosen_sample_list中有重复的
                    choosen_sample_list.extend(borrow_list[:self.voter_number - action_len])
                    if len(choosen_sample_list) < self.voter_number:
                        choosen_sample_list.extend(choosen_sample_list[:self.voter_number - len(choosen_sample_list)])
            elif self.DD_choosing:
                train_file_list = self.difficulties_dict[self.data_anno[sample_1][2]]
                random.shuffle(train_file_list)
                choosen_sample_list = train_file_list[:self.voter_number]
            else:
                # randomly
                train_file_list = self.choose_list
                random.shuffle(train_file_list)
                choosen_sample_list = train_file_list[:self.voter_number]

            target_list = []
            for item in choosen_sample_list:
                tmp = {}
                tmp['video'] = self.load_video(item, subset='train')
                tmp['number'] = self.train_anno.get(item)['action_type']
                tmp['final_score'] = self.train_anno.get(item)['dive_score']
                tmp['difficulty'] = self.train_anno.get(item)['difficulty']
                tmp['completeness'] = round((tmp['final_score'] / tmp['difficulty']), 1)
                tmp['judge_scores'] = np.array(self.train_anno.get(item)['judge_scores']).astype(np.float32)
                if round(sum(tmp['judge_scores']), 1) != tmp['completeness']:
                    print("select test judge scores Error!%s" % (item))
                target_list.append(tmp)
            return data, target_list

    def __len__(self):
        return len(self.dataset)
